# bad animation #1

A Pen created on CodePen.io. Original URL: [https://codepen.io/MaxGraph/pen/GRNdQjb](https://codepen.io/MaxGraph/pen/GRNdQjb).

