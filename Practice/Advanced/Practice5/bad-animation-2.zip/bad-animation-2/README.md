# bad animation #2

A Pen created on CodePen.io. Original URL: [https://codepen.io/jurmaev/pen/YzvgaNJ](https://codepen.io/jurmaev/pen/YzvgaNJ).

